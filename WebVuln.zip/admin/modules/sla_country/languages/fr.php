<?php
/**
* @package		SLASH-CMS
* @subpackage	FR COUNTRY MODULE LANGUAGES
* @internal     French categories module translate
* @version		fr.php - Version 11.1.14
* @author		Julien Veuillet [http://www.wakdev.com]
* @copyright	Copyright(C) 2011 - Today. All rights reserved.
* @license		GNU/GPL
*/


//Module SLA_COUNTRY
define("COUNTRY_TITLE", "Gestion des pays");
define("COUNTRY_DELETE_CONFIRM", "Supprimer ce pays ?");
define("COUNTRY_ERROR_EXIST", "Ce pays exite d&eacute;j&agrave; !");
define("COUNTRY_SHORTNAME", "Nom abr&eacute;g&eacute;");
?>
