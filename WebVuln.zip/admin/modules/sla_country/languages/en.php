<?php
/**
* @package		SLASH-CMS
* @subpackage	EN COUNTRY MODULE LANGUAGES
* @internal     English categories module translate
* @version		en.php - Version 11.1.14
* @author		Julien Veuillet [http://www.wakdev.com]
* @copyright	Copyright(C) 2011 - Today. All rights reserved.
* @license		GNU/GPL
*/


//Module SLA_CATEGORIES
define("COUNTRY_TITLE", "Country config");
define("COUNTRY_DELETE_CONFIRM", "Delete this country ?");
define("COUNTRY_ERROR_EXIST", "This country already exist !");
define("COUNTRY_SHORTNAME", "Shortname");
?>
